from .compress_json import load, dump, local_load, local_dump

__all__ = ["load", "dump", "local_load", "local_dump"]