from .compress_json import load, dump

__all__ = ["load", "dump"]